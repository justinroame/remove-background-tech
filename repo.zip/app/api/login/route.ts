import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { setUserSessionCookie } from "@/lib/serverAuth";

export async function POST(req: Request) {
  const { email } = await req.json();

  if (!email || typeof email !== "string") {
    return NextResponse.json(
      { error: "Email required" },
      { status: 400 }
    );
  }

  const [user] = await db
    .select()
    .from(users)
    .where(eq(users.email, email.toLowerCase()))
    .limit(1);

  if (!user) {
    return NextResponse.json(
      { error: "Account not found" },
      { status: 404 }
    );
  }

  await setUserSessionCookie({
    id: user.id,
    email: user.email,
  });

  return NextResponse.json({ success: true });
}
